import crypto from 'crypto';

class AIService {
  private readonly ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'default-key-for-development-only';

  async encryptApiKey(apiKey: string): Promise<string> {
    const cipher = crypto.createCipher('aes256', this.ENCRYPTION_KEY);
    let encrypted = cipher.update(apiKey, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
  }

  async decryptApiKey(encryptedKey: string): Promise<string> {
    const decipher = crypto.createDecipher('aes256', this.ENCRYPTION_KEY);
    let decrypted = decipher.update(encryptedKey, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  }

  async testApiConnection(provider: string, apiKey: string): Promise<boolean> {
    try {
      if (provider === 'google') {
        return await this.testGoogleAI(apiKey);
      } else if (provider === 'openai') {
        return await this.testOpenAI(apiKey);
      }
      return false;
    } catch (error) {
      console.error(`API test failed for ${provider}:`, error);
      return false;
    }
  }

  private async testGoogleAI(apiKey: string): Promise<boolean> {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{ text: 'Test connection' }]
          }]
        })
      }
    );
    return response.ok;
  }

  private async testOpenAI(apiKey: string): Promise<boolean> {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: 'Test connection' }],
        max_tokens: 5
      })
    });
    return response.ok;
  }

  async generateContent(prompt: string, provider: string, apiKey: string): Promise<string> {
    if (provider === 'google') {
      return await this.generateWithGoogle(prompt, apiKey);
    } else if (provider === 'openai') {
      return await this.generateWithOpenAI(prompt, apiKey);
    }
    throw new Error('Unsupported AI provider');
  }

  private async generateWithGoogle(prompt: string, apiKey: string): Promise<string> {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{ text: prompt }]
          }]
        })
      }
    );

    if (!response.ok) {
      throw new Error(`Google AI API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || '';
  }

  private async generateWithOpenAI(prompt: string, apiKey: string): Promise<string> {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 4000
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content || '';
  }
}

export const aiService = new AIService();
