// Utility functions for API interactions
export class APIClient {
  private static baseUrl = "";

  static async generateContent(request: any, fraudHeaders: Record<string, string> = {}) {
    const response = await fetch(`${this.baseUrl}/api/generate-content`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...fraudHeaders,
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || `API Error: ${response.statusText}`);
    }

    return response.json();
  }

  static async saveApiKeys(keys: any) {
    const response = await fetch(`${this.baseUrl}/api/api-keys`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(keys),
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }

    return response.json();
  }

  static async testApiConnection(provider: string, apiKey: string) {
    const response = await fetch(`${this.baseUrl}/api/test-api`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ provider, apiKey }),
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }

    return response.json();
  }
}
