import { 
  users, apiKeys, articles, payments, abuseDetection,
  type User, type InsertUser,
  type ApiKey, type InsertApiKey,
  type Article, type InsertArticle,
  type Payment, type InsertPayment,
  type AbuseDetection, type InsertAbuseDetection
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserCredits(userId: number, credits: number): Promise<User>;
  updateUserFreeArticles(userId: number, count: number): Promise<User>;
  setUserHasApiKey(userId: number, hasKey: boolean): Promise<User>;

  // API Key operations
  saveApiKey(apiKey: InsertApiKey): Promise<ApiKey>;
  getUserApiKeys(userId: number): Promise<ApiKey[]>;
  deleteApiKey(userId: number, provider: string): Promise<void>;
  clearExpiredApiKeys(): Promise<void>;

  // Article operations
  createArticle(article: InsertArticle): Promise<Article>;
  getArticle(id: number): Promise<Article | undefined>;
  getUserArticles(userId: number): Promise<Article[]>;
  updateArticlePaymentStatus(articleId: number, isPaid: boolean, method: string): Promise<Article>;

  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPayment(id: number): Promise<Payment | undefined>;
  updatePaymentStatus(id: number, status: string): Promise<Payment>;

  // Abuse detection operations
  getAbuseRecord(ipAddress: string): Promise<AbuseDetection | undefined>;
  createOrUpdateAbuseRecord(record: Partial<InsertAbuseDetection> & { ipAddress: string }): Promise<AbuseDetection>;
  incrementFreeArticleUsage(ipAddress: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private apiKeys: Map<number, ApiKey> = new Map();
  private articles: Map<number, Article> = new Map();
  private payments: Map<number, Payment> = new Map();
  private abuseRecords: Map<string, AbuseDetection> = new Map();
  
  private currentUserId = 1;
  private currentApiKeyId = 1;
  private currentArticleId = 1;
  private currentPaymentId = 1;
  private currentAbuseRecordId = 1;

  constructor() {
    // Create default user
    this.users.set(1, {
      id: 1,
      credits: 0,
      freeArticlesUsed: 0,
      hasOwnApiKey: false,
      userAgent: null,
      ipAddress: null,
      browserFingerprint: null,
      sessionId: null,
      isFlagged: false,
      createdAt: new Date(),
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      id,
      credits: insertUser.credits || 0,
      freeArticlesUsed: insertUser.freeArticlesUsed || 0,
      hasOwnApiKey: insertUser.hasOwnApiKey || false,
      userAgent: insertUser.userAgent || null,
      ipAddress: insertUser.ipAddress || null,
      browserFingerprint: insertUser.browserFingerprint || null,
      sessionId: insertUser.sessionId || null,
      isFlagged: insertUser.isFlagged || false,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserCredits(userId: number, credits: number): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, credits };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async updateUserFreeArticles(userId: number, count: number): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, freeArticlesUsed: count };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async setUserHasApiKey(userId: number, hasKey: boolean): Promise<User> {
    const user = this.users.get(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, hasOwnApiKey: hasKey };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async saveApiKey(insertApiKey: InsertApiKey): Promise<ApiKey> {
    const id = this.currentApiKeyId++;
    const apiKey: ApiKey = {
      id,
      createdAt: new Date(),
      userId: insertApiKey.userId || 0,
      provider: insertApiKey.provider,
      encryptedKey: insertApiKey.encryptedKey,
      isActive: insertApiKey.isActive || false,
      expiresAt: insertApiKey.expiresAt || null,
    };
    this.apiKeys.set(id, apiKey);
    return apiKey;
  }

  async getUserApiKeys(userId: number): Promise<ApiKey[]> {
    return Array.from(this.apiKeys.values()).filter(key => key.userId === userId);
  }

  async deleteApiKey(userId: number, provider: string): Promise<void> {
    for (const [id, key] of this.apiKeys.entries()) {
      if (key.userId === userId && key.provider === provider) {
        this.apiKeys.delete(id);
        break;
      }
    }
  }

  async clearExpiredApiKeys(): Promise<void> {
    const now = new Date();
    for (const [id, key] of this.apiKeys.entries()) {
      if (key.expiresAt && key.expiresAt < now) {
        this.apiKeys.delete(id);
      }
    }
  }

  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const id = this.currentArticleId++;
    const article: Article = {
      id,
      createdAt: new Date(),
      userId: insertArticle.userId || 0,
      title: insertArticle.title,
      content: insertArticle.content,
      seoScore: insertArticle.seoScore || 0,
      metadata: insertArticle.metadata || null,
      isPaid: insertArticle.isPaid || false,
      paymentMethod: insertArticle.paymentMethod || null,
    };
    this.articles.set(id, article);
    return article;
  }

  async getArticle(id: number): Promise<Article | undefined> {
    return this.articles.get(id);
  }

  async getUserArticles(userId: number): Promise<Article[]> {
    return Array.from(this.articles.values()).filter(article => article.userId === userId);
  }

  async updateArticlePaymentStatus(articleId: number, isPaid: boolean, method: string): Promise<Article> {
    const article = this.articles.get(articleId);
    if (!article) throw new Error("Article not found");
    
    const updatedArticle = { ...article, isPaid, paymentMethod: method };
    this.articles.set(articleId, updatedArticle);
    return updatedArticle;
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = this.currentPaymentId++;
    const payment: Payment = {
      id,
      createdAt: new Date(),
      userId: insertPayment.userId || 0,
      amount: insertPayment.amount || 0,
      type: insertPayment.type,
      status: insertPayment.status,
      articleId: insertPayment.articleId || null,
      stripePaymentIntentId: insertPayment.stripePaymentIntentId || null,
    };
    this.payments.set(id, payment);
    return payment;
  }

  async getPayment(id: number): Promise<Payment | undefined> {
    return this.payments.get(id);
  }

  async updatePaymentStatus(id: number, status: string): Promise<Payment> {
    const payment = this.payments.get(id);
    if (!payment) throw new Error("Payment not found");
    
    const updatedPayment = { ...payment, status };
    this.payments.set(id, updatedPayment);
    return updatedPayment;
  }

  // Abuse detection operations
  async getAbuseRecord(ipAddress: string): Promise<AbuseDetection | undefined> {
    return this.abuseRecords.get(ipAddress);
  }

  async createOrUpdateAbuseRecord(record: Partial<InsertAbuseDetection> & { ipAddress: string }): Promise<AbuseDetection> {
    const existing = this.abuseRecords.get(record.ipAddress);
    
    if (existing) {
      const updated: AbuseDetection = {
        ...existing,
        ...record,
        usersCreated: (existing.usersCreated || 0) + (record.usersCreated || 0),
        freeArticlesUsed: (existing.freeArticlesUsed || 0) + (record.freeArticlesUsed || 0),
        lastActivity: new Date(),
      };
      this.abuseRecords.set(record.ipAddress, updated);
      return updated;
    } else {
      const id = this.currentAbuseRecordId++;
      const newRecord: AbuseDetection = {
        id,
        ipAddress: record.ipAddress,
        browserFingerprint: record.browserFingerprint || null,
        userAgent: record.userAgent || null,
        freeArticlesUsed: record.freeArticlesUsed || 0,
        usersCreated: record.usersCreated || 0,
        isBanned: record.isBanned || false,
        isVpn: record.isVpn || false,
        isProxy: record.isProxy || false,
        isDataCenter: record.isDataCenter || false,
        ipCountry: record.ipCountry || null,
        ipRiskScore: record.ipRiskScore || 0,
        lastActivity: new Date(),
        createdAt: new Date(),
      };
      this.abuseRecords.set(record.ipAddress, newRecord);
      return newRecord;
    }
  }

  async incrementFreeArticleUsage(ipAddress: string): Promise<void> {
    const existing = await this.getAbuseRecord(ipAddress);
    if (existing) {
      await this.createOrUpdateAbuseRecord({
        ...existing,
        freeArticlesUsed: 1,
      });
    } else {
      await this.createOrUpdateAbuseRecord({
        ipAddress,
        freeArticlesUsed: 1,
      });
    }
  }
}

export const storage = new MemStorage();
