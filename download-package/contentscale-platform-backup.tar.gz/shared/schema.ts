import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  credits: integer("credits").default(0),
  freeArticlesUsed: integer("free_articles_used").default(0),
  hasOwnApiKey: boolean("has_own_api_key").default(false),
  userAgent: text("user_agent"), // Browser fingerprint
  ipAddress: text("ip_address"), // IP tracking
  browserFingerprint: text("browser_fingerprint"), // Unique browser signature
  sessionId: text("session_id"), // Session tracking
  isFlagged: boolean("is_flagged").default(false), // Abuse detection flag
  createdAt: timestamp("created_at").defaultNow(),
});

export const apiKeys = pgTable("api_keys", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  provider: text("provider").notNull(), // 'google' | 'openai'
  encryptedKey: text("encrypted_key").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at"), // 24 hour expiry
});

export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: text("title").notNull(),
  content: text("content").notNull(),
  seoScore: integer("seo_score"),
  metadata: jsonb("metadata"), // topic, keywords, audience, etc.
  isPaid: boolean("is_paid").default(false),
  paymentMethod: text("payment_method"), // 'credits' | 'single' | 'free'
  createdAt: timestamp("created_at").defaultNow(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  articleId: integer("article_id").references(() => articles.id),
  amount: integer("amount"), // in cents
  type: text("type").notNull(), // 'credits' | 'single'
  status: text("status").notNull(), // 'pending' | 'completed' | 'failed'
  stripePaymentIntentId: text("stripe_payment_intent_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Abuse tracking table
export const abuseDetection = pgTable("abuse_detection", {
  id: serial("id").primaryKey(),
  ipAddress: text("ip_address").notNull(),
  browserFingerprint: text("browser_fingerprint"),
  userAgent: text("user_agent"),
  freeArticlesUsed: integer("free_articles_used").default(0),
  usersCreated: integer("users_created").default(0),
  isBanned: boolean("is_banned").default(false),
  isVpn: boolean("is_vpn").default(false),
  isProxy: boolean("is_proxy").default(false),
  isDataCenter: boolean("is_datacenter").default(false),
  ipCountry: text("ip_country"),
  ipRiskScore: integer("ip_risk_score").default(0), // 0-100 risk score
  lastActivity: timestamp("last_activity").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertApiKeySchema = createInsertSchema(apiKeys).omit({
  id: true,
  createdAt: true,
});

export const insertArticleSchema = createInsertSchema(articles).omit({
  id: true,
  createdAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
});

export const insertAbuseDetectionSchema = createInsertSchema(abuseDetection).omit({
  id: true,
  createdAt: true,
  lastActivity: true,
});

// Content generation request schema
export const contentGenerationSchema = z.object({
  topic: z.string().min(1, "Topic is required"),
  keywords: z.string().optional(),
  audience: z.string().optional(),
  niche: z.string().optional(),
  language: z.string().default("english"),
  wordCount: z.number().min(500).max(5000).default(1000),
});

// API key validation schemas
export const apiKeyConfigSchema = z.object({
  googleApiKey: z.string().optional(),
  openaiApiKey: z.string().optional(),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type ApiKey = typeof apiKeys.$inferSelect;
export type InsertApiKey = z.infer<typeof insertApiKeySchema>;

export type Article = typeof articles.$inferSelect;
export type InsertArticle = z.infer<typeof insertArticleSchema>;

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

export type AbuseDetection = typeof abuseDetection.$inferSelect;
export type InsertAbuseDetection = z.infer<typeof insertAbuseDetectionSchema>;

export type ContentGenerationRequest = z.infer<typeof contentGenerationSchema>;
export type ApiKeyConfig = z.infer<typeof apiKeyConfigSchema>;
