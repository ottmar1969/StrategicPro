import { storage } from "../storage";
import { aiService } from "./ai-service";
import type { ContentGenerationRequest } from "@shared/schema";

interface GeneratedContent {
  title: string;
  content: string;
  seoScore: number;
  craftAnalysis: {
    cut: string;
    review: string;
    add: string;
    factCheck: string;
    trust: string;
  };
}

class ContentGenerator {
  async generateWithCRAFT(
    request: ContentGenerationRequest, 
    userId: number
  ): Promise<GeneratedContent> {
    // Get user's API keys
    const apiKeys = await storage.getUserApiKeys(userId);
    const activeKeys = apiKeys.filter(key => key.isActive);

    if (activeKeys.length === 0) {
      throw new Error('No active API keys found');
    }

    // Prioritize Google AI
    let apiKey = activeKeys.find(key => key.provider === 'google');
    if (!apiKey) {
      apiKey = activeKeys.find(key => key.provider === 'openai');
    }

    if (!apiKey) {
      throw new Error('No suitable API key found');
    }

    const decryptedKey = await aiService.decryptApiKey(apiKey.encryptedKey);
    
    // Generate CRAFT-optimized prompt
    const craftPrompt = this.buildCRAFTPrompt(request);
    
    try {
      // Generate content with primary provider
      const content = await aiService.generateContent(craftPrompt, apiKey.provider, decryptedKey);
      
      // Parse and structure the content
      const structuredContent = this.parseGeneratedContent(content, request);
      
      return structuredContent;
    } catch (error) {
      // Try fallback provider if available
      const fallbackKey = activeKeys.find(key => key.provider !== apiKey.provider);
      if (fallbackKey) {
        const fallbackDecryptedKey = await aiService.decryptApiKey(fallbackKey.encryptedKey);
        const content = await aiService.generateContent(craftPrompt, fallbackKey.provider, fallbackDecryptedKey);
        return this.parseGeneratedContent(content, request);
      }
      
      throw error;
    }
  }

  private buildCRAFTPrompt(request: ContentGenerationRequest): string {
    return `
You are ContentScale's advanced AI content generator. Create SEO-optimized content using the CRAFT Framework for Google AI Overview optimization.

CRAFT Framework Implementation:
- CUT: Remove unnecessary fluff, focus on value-driven content
- REVIEW: Optimize for SEO with proper headings, meta elements, and structure
- ADD: Suggest visual elements and engagement features
- FACT-CHECK: Ensure accuracy and include credible sources
- TRUST: Build authority with personal insights and authentic tone

Content Requirements:
- Topic: ${request.topic}
- Keywords: ${request.keywords || 'Auto-generate relevant keywords'}
- Target Audience: ${request.audience || 'General'}
- Niche: ${request.niche || 'General'}
- Language: ${request.language}
- Word Count: ${request.wordCount} words
- Google AI Overview Optimization: Structure content to appear in AI-generated search results

Output Format (JSON):
{
  "title": "SEO-optimized title (60 chars max)",
  "content": "Full article content with HTML formatting",
  "seoScore": number (1-100),
  "craftAnalysis": {
    "cut": "What was removed/streamlined",
    "review": "SEO optimizations applied",
    "add": "Visual/engagement suggestions",
    "factCheck": "Sources and verification notes",
    "trust": "Authority-building elements added"
  },
  "keywords": ["extracted", "keywords"],
  "aiOverviewOptimization": "Specific optimizations for Google AI Overview"
}

Focus on:
1. Question-focused structure for AI Overview inclusion
2. Concise, authoritative answers that Google AI can reference
3. E-E-A-T signals (Experience, Expertise, Authoritativeness, Trustworthiness)
4. Low-competition keyword targeting
5. Human-like authenticity that passes AI detection

Generate the content now:
`;
  }

  private parseGeneratedContent(rawContent: string, request: ContentGenerationRequest): GeneratedContent {
    try {
      // Try to parse as JSON first
      const parsed = JSON.parse(rawContent);
      return {
        title: parsed.title || `${request.topic} - Complete Guide`,
        content: parsed.content || rawContent,
        seoScore: parsed.seoScore || this.calculateSEOScore(rawContent),
        craftAnalysis: parsed.craftAnalysis || this.generateDefaultCRAFTAnalysis(),
      };
    } catch {
      // Fallback if not JSON
      return {
        title: `${request.topic} - Complete Guide`,
        content: rawContent,
        seoScore: this.calculateSEOScore(rawContent),
        craftAnalysis: this.generateDefaultCRAFTAnalysis(),
      };
    }
  }

  private calculateSEOScore(content: string): number {
    let score = 50; // Base score
    
    // Check for headings
    if (content.includes('<h1>') || content.includes('<h2>')) score += 10;
    
    // Check for sufficient length
    if (content.length > 1000) score += 10;
    if (content.length > 2000) score += 5;
    
    // Check for lists
    if (content.includes('<ul>') || content.includes('<ol>')) score += 5;
    
    // Check for bold/emphasis
    if (content.includes('<strong>') || content.includes('<em>')) score += 5;
    
    // Check for internal structure
    if (content.split('\n').length > 10) score += 10;
    
    return Math.min(score, 95); // Cap at 95 for realism
  }

  private generateDefaultCRAFTAnalysis() {
    return {
      cut: "Removed unnecessary filler words and focused on value-driven content",
      review: "Optimized headings, structure, and keyword placement for SEO",
      add: "Suggested relevant images, charts, and interactive elements",
      factCheck: "Verified information accuracy and included credible sources",
      trust: "Added authority signals and authentic, human-like tone"
    };
  }
}

export const contentGenerator = new ContentGenerator();
