import { Card } from "@/components/ui/card";
import { CheckCircle } from "lucide-react";

export default function GoogleAISection() {
  const aiOverviewFeatures = [
    "Question-focused content structure",
    "Concise, authoritative answers", 
    "Schema markup optimization",
    "E-E-A-T signal enhancement"
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Master Google's AI Overview with Our Advanced Google AI Mode
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Google's AI Overview is changing how content ranks. Our Google AI mode creates content specifically optimized to appear in AI-generated search results.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="AI Overview optimization dashboard showing ranking metrics" 
              className="rounded-xl shadow-2xl w-full" 
            />
          </div>
          
          <div className="space-y-6">
            <Card className="bg-indigo-50 border-indigo-200 p-6">
              <h3 className="text-xl font-semibold text-indigo-900 mb-3">What is Google AI Overview?</h3>
              <p className="text-indigo-700">
                Google's AI Overview appears at the top of search results, providing AI-generated summaries. Content that ranks here gets massive visibility and traffic.
              </p>
            </Card>
            
            <Card className="bg-green-50 border-green-200 p-6">
              <h3 className="text-xl font-semibold text-green-900 mb-3">Our Google AI Mode Advantage</h3>
              <p className="text-green-700">
                We use Google's own AI (Gemini 2.5 Flash) to create content that speaks the same "language" as Google's ranking algorithms, increasing your chances of AI Overview inclusion.
              </p>
            </Card>
            
            <Card className="bg-amber-50 border-amber-200 p-6">
              <h3 className="text-xl font-semibold text-amber-900 mb-3">AI Overview Optimization Features</h3>
              <ul className="space-y-2 text-amber-700">
                {aiOverviewFeatures.map((feature, index) => (
                  <li key={index} className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-amber-600" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
