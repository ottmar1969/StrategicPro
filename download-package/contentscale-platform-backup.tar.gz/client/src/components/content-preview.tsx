import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, Copy, Share2, CreditCard, Package } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ContentPreviewProps {
  content: {
    article: {
      id: number;
      title: string;
      content: string;
      seoScore: number;
      isPaid: boolean;
    };
    watermarked: boolean;
  };
}

export default function ContentPreview({ content }: ContentPreviewProps) {
  const { toast } = useToast();
  const [showWatermark, setShowWatermark] = useState(content.watermarked);

  const handleDownload = () => {
    if (content.watermarked) {
      // Show payment options
      return;
    }

    const dataStr = JSON.stringify(content.article, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `${content.article.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleCopy = () => {
    if (content.watermarked) {
      toast({
        title: "Premium Feature",
        description: "Purchase the article to copy content without watermark.",
        variant: "destructive",
      });
      return;
    }

    navigator.clipboard.writeText(content.article.content);
    toast({
      title: "Copied!",
      description: "Article content copied to clipboard.",
    });
  };

  const handleShare = () => {
    const shareData = {
      title: content.article.title,
      text: "Check out this AI-generated article created with ContentScale's CRAFT Framework!",
      url: window.location.href,
    };

    if (navigator.share) {
      navigator.share(shareData);
    } else {
      navigator.clipboard.writeText(shareData.url);
      toast({
        title: "Link Copied",
        description: "Share link copied to clipboard.",
      });
    }
  };

  const handlePurchaseSingle = () => {
    // TODO: Implement single article purchase
    toast({
      title: "Coming Soon",
      description: "Single article purchase will be available shortly.",
    });
  };

  const handleBuyCredits = () => {
    // TODO: Scroll to pricing section or open modal
    const pricingSection = document.getElementById('pricing');
    if (pricingSection) {
      pricingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="mt-8 relative">
      <Card className="bg-gray-50 border border-gray-200 shadow-lg">
        {/* Watermark Overlay */}
        {showWatermark && (
          <div className="watermark-overlay">
            <div className="text-center">
              <div className="text-6xl mb-4">🔒</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Premium Content</h3>
              <p className="text-gray-600 mb-6 max-w-md">
                This article is ready! Purchase to remove watermark and get full access.
              </p>
              <div className="space-y-3">
                <Button 
                  onClick={handlePurchaseSingle}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 font-semibold w-full"
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  Purchase Article - $10
                </Button>
                <Button 
                  onClick={handleBuyCredits}
                  variant="secondary"
                  className="bg-gray-600 hover:bg-gray-700 text-white px-8 py-3 font-semibold w-full"
                >
                  <Package className="w-4 h-4 mr-2" />
                  Buy Credits Pack
                </Button>
              </div>
            </div>
          </div>
        )}

        <CardContent className="p-8">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <span className="text-2xl font-bold text-green-600">#1</span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-900">{content.article.title}</h3>
                <p className="text-sm text-green-600 font-medium">
                  Created with ContentScale CRAFT Framework
                </p>
              </div>
            </div>
            
            {/* SEO Score */}
            <Badge className="bg-green-100 text-green-800 px-4 py-2">
              <div className="text-center">
                <div className="text-xs font-medium">SEO Score</div>
                <div className="text-lg font-bold">{content.article.seoScore}</div>
              </div>
            </Badge>
          </div>

          {/* Content Preview */}
          <div className="prose max-w-none mb-8">
            <div dangerouslySetInnerHTML={{ __html: content.article.content.substring(0, 500) + "..." }} />
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-4 pt-6 border-t border-gray-200">
            <Button onClick={handleDownload} variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Download JSON
            </Button>
            <Button onClick={handleCopy} variant="outline">
              <Copy className="w-4 h-4 mr-2" />
              Copy Content
            </Button>
            <Button onClick={handleShare} variant="outline">
              <Share2 className="w-4 h-4 mr-2" />
              Share Article
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
