// Client-side encryption utilities for additional security
export class EncryptionUtils {
  static async hashApiKey(apiKey: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(apiKey);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  static validateApiKeyFormat(provider: string, apiKey: string): boolean {
    if (provider === 'google') {
      return apiKey.startsWith('AIza') && apiKey.length > 20;
    } else if (provider === 'openai') {
      return apiKey.startsWith('sk-') && apiKey.length > 40;
    }
    return false;
  }

  static maskApiKey(apiKey: string): string {
    if (apiKey.length < 8) return '****';
    return apiKey.substring(0, 4) + '...' + apiKey.substring(apiKey.length - 4);
  }
}
