import { storage } from "../storage";

interface CanGenerateResult {
  allowed: boolean;
  method: 'free' | 'credits' | 'payment_required';
  remaining?: number;
  message?: string;
}

class PaymentService {
  async canUserGenerateContent(userId: number): Promise<CanGenerateResult> {
    const user = await storage.getUser(userId);
    if (!user) {
      return { allowed: false, method: 'payment_required', message: 'User not found' };
    }

    const freeArticlesUsed = user.freeArticlesUsed || 0;
    const credits = user.credits || 0;
    const hasApiKey = user.hasOwnApiKey || false;

    // First article is always free for everyone
    if (freeArticlesUsed === 0) {
      return { 
        allowed: true, 
        method: 'free', 
        remaining: 1,
        message: 'First article free for all users' 
      };
    }

    // Second article: requires payment or credits unless they have API key
    if (freeArticlesUsed === 1 && !hasApiKey) {
      return { 
        allowed: false, 
        method: 'payment_required', 
        message: 'Second article requires payment ($10) or credits. Add your API key for 10 free articles!' 
      };
    }

    // Users with API key get 10 free articles total
    if (hasApiKey && freeArticlesUsed < 10) {
      return { 
        allowed: true, 
        method: 'free', 
        remaining: 10 - freeArticlesUsed 
      };
    }

    // After 10 free articles with API key, charge $1 per article
    if (hasApiKey && freeArticlesUsed >= 10) {
      return { 
        allowed: false, 
        method: 'payment_required', 
        message: 'With your API key: $1 per article after 10 free articles' 
      };
    }

    // Check if user has credits
    if (credits > 0) {
      return { 
        allowed: true, 
        method: 'credits', 
        remaining: credits 
      };
    }

    // Payment required
    return { 
      allowed: false, 
      method: 'payment_required', 
      message: 'No credits remaining. Buy credits or pay per article.' 
    };
  }

  getCreditPackages() {
    return [
      {
        id: 'starter',
        name: 'Starter Pack',
        credits: 5,
        price: 25,
        pricePerCredit: 5.00,
        popular: false,
      },
      {
        id: 'popular',
        name: 'Popular Pack',
        credits: 10,
        price: 40,
        pricePerCredit: 4.00,
        popular: true,
        savings: 20,
      },
      {
        id: 'professional',
        name: 'Professional Pack',
        credits: 25,
        price: 75,
        pricePerCredit: 3.00,
        popular: false,
        savings: 40,
      },
    ];
  }

  getPayPerUseOptions(hasApiKey: boolean = false) {
    if (hasApiKey) {
      return {
        bulk: { price: 1, description: 'per article (with your API key)' },
        single: { price: 1, description: 'per article (with your API key)' },
      };
    }
    return {
      bulk: { price: 1, description: 'per article (bulk generation)' },
      single: { price: 10, description: 'per individual article' },
    };
  }
}

export const paymentService = new PaymentService();
