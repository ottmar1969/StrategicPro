import { storage } from "../storage";

interface IPAnalysisResult {
  isVpn: boolean;
  isProxy: boolean;
  isDataCenter: boolean;
  country: string;
  riskScore: number; // 0-100
  isSuspicious: boolean;
}

interface DeviceFingerprint {
  userAgent: string;
  browserFingerprint: string;
  sessionId: string;
}

interface FraudCheckResult {
  allowed: boolean;
  reason?: string;
  riskScore: number;
  requiresVerification: boolean;
}

class FraudDetectionService {
  // Known VPN/VPS IP ranges and patterns
  private readonly suspiciousProviders = [
    'amazonaws', 'googlecloud', 'azure', 'digitalocean', 'vultr', 'linode',
    'ovh', 'hetzner', 'scaleway', 'nordvpn', 'expressvpn', 'surfshark',
    'tor', 'proxy', 'vpn', 'datacenter', 'hosting'
  ];

  // Suspicious user agent patterns
  private readonly suspiciousUserAgents = [
    'bot', 'crawler', 'spider', 'scraper', 'automated', 'headless',
    'phantom', 'selenium', 'puppeteer', 'playwright'
  ];

  async analyzeIP(ipAddress: string): Promise<IPAnalysisResult> {
    // Basic IP analysis - in production, use services like IPQualityScore or MaxMind
    const isPrivateIP = this.isPrivateIP(ipAddress);
    let isVpn = false;
    let isProxy = false;
    let isDataCenter = false;
    let riskScore = 0;
    let country = 'Unknown';

    // Check against known VPN/VPS patterns
    const reverseDNS = await this.getReverseDNS(ipAddress);
    
    if (reverseDNS) {
      const lowerDNS = reverseDNS.toLowerCase();
      for (const provider of this.suspiciousProviders) {
        if (lowerDNS.includes(provider)) {
          if (provider.includes('vpn')) {
            isVpn = true;
            riskScore += 80;
          } else if (['amazonaws', 'googlecloud', 'azure', 'digitalocean'].includes(provider)) {
            isDataCenter = true;
            riskScore += 70;
          } else if (provider.includes('proxy')) {
            isProxy = true;
            riskScore += 75;
          }
        }
      }
    }

    // Additional risk factors
    if (isPrivateIP) riskScore += 90; // Local/private IPs are highly suspicious
    if (this.isKnownTorExit(ipAddress)) {
      riskScore += 95;
      isProxy = true;
    }

    const isSuspicious = riskScore > 50;

    return {
      isVpn,
      isProxy,
      isDataCenter,
      country,
      riskScore: Math.min(riskScore, 100),
      isSuspicious
    };
  }

  async checkDeviceFingerprint(fingerprint: DeviceFingerprint, ipAddress: string): Promise<FraudCheckResult> {
    const { userAgent, browserFingerprint, sessionId } = fingerprint;
    let riskScore = 0;
    let reasons: string[] = [];

    // Check user agent
    const lowerUA = userAgent.toLowerCase();
    for (const suspicious of this.suspiciousUserAgents) {
      if (lowerUA.includes(suspicious)) {
        riskScore += 60;
        reasons.push('Suspicious user agent detected');
        break;
      }
    }

    // Check for common automation signatures
    if (this.detectAutomation(userAgent, browserFingerprint)) {
      riskScore += 80;
      reasons.push('Automation detected');
    }

    // Check IP analysis
    const ipAnalysis = await this.analyzeIP(ipAddress);
    riskScore += ipAnalysis.riskScore * 0.8; // Weight IP analysis

    if (ipAnalysis.isVpn) reasons.push('VPN detected');
    if (ipAnalysis.isDataCenter) reasons.push('Data center IP detected');
    if (ipAnalysis.isProxy) reasons.push('Proxy detected');

    // Check existing abuse records
    const abuseRecord = await storage.getAbuseRecord?.(ipAddress);
    if (abuseRecord) {
      if (abuseRecord.isBanned) {
        return {
          allowed: false,
          reason: 'IP address is banned',
          riskScore: 100,
          requiresVerification: false
        };
      }
      
      if ((abuseRecord.usersCreated || 0) > 3) {
        riskScore += 40;
        reasons.push('Multiple accounts from same IP');
      }
      
      if ((abuseRecord.freeArticlesUsed || 0) > 15) {
        riskScore += 50;
        reasons.push('Excessive free usage from IP');
      }
    }

    const finalRiskScore = Math.min(riskScore, 100);
    
    return {
      allowed: finalRiskScore < 75,
      reason: reasons.length > 0 ? reasons.join(', ') : undefined,
      riskScore: finalRiskScore,
      requiresVerification: finalRiskScore > 50 && finalRiskScore < 75
    };
  }

  async trackUserCreation(ipAddress: string, fingerprint: DeviceFingerprint): Promise<void> {
    const ipAnalysis = await this.analyzeIP(ipAddress);
    
    // Create or update abuse detection record
    await storage.createOrUpdateAbuseRecord?.({
      ipAddress,
      browserFingerprint: fingerprint.browserFingerprint,
      userAgent: fingerprint.userAgent,
      usersCreated: 1,
      isVpn: ipAnalysis.isVpn,
      isProxy: ipAnalysis.isProxy,
      isDataCenter: ipAnalysis.isDataCenter,
      ipCountry: ipAnalysis.country,
      ipRiskScore: ipAnalysis.riskScore,
    });
  }

  async trackArticleGeneration(ipAddress: string): Promise<void> {
    await storage.incrementFreeArticleUsage?.(ipAddress);
  }

  private isPrivateIP(ip: string): boolean {
    // Check for private IP ranges
    const privateRanges = [
      /^10\./,
      /^172\.(1[6-9]|2[0-9]|3[0-1])\./,
      /^192\.168\./,
      /^127\./,
      /^169\.254\./,
      /^::1$/,
      /^fc00:/,
      /^fe80:/
    ];
    
    return privateRanges.some(range => range.test(ip));
  }

  private async getReverseDNS(ip: string): Promise<string | null> {
    try {
      // In production, implement actual reverse DNS lookup
      // For now, return null to avoid network calls in demo
      return null;
    } catch {
      return null;
    }
  }

  private isKnownTorExit(ip: string): boolean {
    // In production, check against Tor exit node list
    // This is a simplified check
    return false;
  }

  private detectAutomation(userAgent: string, browserFingerprint: string): boolean {
    // Check for headless browser signatures
    const automationSignatures = [
      'HeadlessChrome',
      'PhantomJS',
      'SlimerJS',
      'webdriver',
      'nightmare'
    ];

    const lowerUA = userAgent.toLowerCase();
    const lowerFP = browserFingerprint.toLowerCase();

    return automationSignatures.some(sig => 
      lowerUA.includes(sig.toLowerCase()) || 
      lowerFP.includes(sig.toLowerCase())
    );
  }

  // Generate browser fingerprint on client side
  generateClientFingerprint(): string {
    return `
      // Add this to client-side code
      function generateBrowserFingerprint() {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        ctx.textBaseline = 'top';
        ctx.font = '14px Arial';
        ctx.fillText('Browser fingerprint', 2, 2);
        
        const fingerprint = {
          screen: screen.width + 'x' + screen.height,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          language: navigator.language,
          platform: navigator.platform,
          cookieEnabled: navigator.cookieEnabled,
          canvas: canvas.toDataURL(),
          webgl: this.getWebGLFingerprint(),
          fonts: this.getFontFingerprint()
        };
        
        return btoa(JSON.stringify(fingerprint));
      }
      
      function getWebGLFingerprint() {
        const canvas = document.createElement('canvas');
        const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
        if (!gl) return '';
        
        const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
        return debugInfo ? 
          gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) + '~' + 
          gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : '';
      }
      
      function getFontFingerprint() {
        const fonts = ['Arial', 'Times', 'Courier', 'Helvetica', 'Georgia'];
        return fonts.filter(font => this.isFontAvailable(font)).join(',');
      }
      
      function isFontAvailable(font) {
        const testString = 'abcdefghijklmnopqrstuvwxyz0123456789';
        const testSize = '72px';
        const h = document.getElementsByTagName('body')[0];
        
        const s = document.createElement('span');
        s.style.fontSize = testSize;
        s.style.fontFamily = font;
        s.innerHTML = testString;
        h.appendChild(s);
        const fontWidth = s.offsetWidth;
        h.removeChild(s);
        
        return fontWidth > 0;
      }
    `;
  }
}

export const fraudDetection = new FraudDetectionService();