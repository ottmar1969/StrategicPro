import { useQuery } from "@tanstack/react-query";

export function useCredits() {
  return useQuery({
    queryKey: ["/api/user/1"],
    staleTime: 30000, // 30 seconds
  });
}
