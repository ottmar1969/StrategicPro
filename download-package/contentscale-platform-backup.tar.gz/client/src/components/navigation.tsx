import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings, Zap } from "lucide-react";
import { useCredits } from "@/hooks/use-credits";
import { useApiKeys } from "@/hooks/use-api-keys";

interface NavigationProps {
  onOpenAISettings: () => void;
}

export default function Navigation({ onOpenAISettings }: NavigationProps) {
  const { data: credits } = useCredits();
  const { hasActiveKeys } = useApiKeys();

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">C</span>
            </div>
            <span className="text-xl font-bold text-gray-900">ContentScale</span>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Credits Display */}
            <div className="hidden sm:flex items-center space-x-2 bg-gray-100 rounded-full px-3 py-1">
              <span className="text-sm text-gray-600">Credits:</span>
              <span className="text-sm font-semibold text-indigo-600">
                {credits?.credits || 0}
              </span>
            </div>

            {/* Free Articles Badge */}
            {hasActiveKeys && (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <Zap className="w-3 h-3 mr-1" />
                {10 - (credits?.freeArticlesUsed || 0)} free left
              </Badge>
            )}
            
            {/* AI Settings Button */}
            <Button 
              onClick={onOpenAISettings}
              className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white"
            >
              <Settings className="w-5 h-5" />
              <span className="hidden sm:inline">AI Settings</span>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
