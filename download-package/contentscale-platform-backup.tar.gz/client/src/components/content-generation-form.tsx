import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { APIClient } from "@/lib/api-client";
import ContentPreview from "./content-preview";
import { useCredits } from "@/hooks/use-credits";
import { useApiKeys } from "@/hooks/use-api-keys";
import { useFraudProtection } from "@/hooks/use-fraud-protection";

interface ContentFormData {
  topic: string;
  keywords: string;
  audience: string;
  niche: string;
  language: string;
  wordCount: number;
}

export default function ContentGenerationForm() {
  const { toast } = useToast();
  const { data: credits } = useCredits();
  const { hasActiveKeys } = useApiKeys();
  const { getHeaders, isReady } = useFraudProtection();
  
  const [formData, setFormData] = useState<ContentFormData>({
    topic: "",
    keywords: "",
    audience: "",
    niche: "",
    language: "english",
    wordCount: 1000,
  });

  const [generatedContent, setGeneratedContent] = useState(null);

  const generateContentMutation = useMutation({
    mutationFn: async (data: ContentFormData) => {
      return await APIClient.generateContent(data, getHeaders());
    },
    onSuccess: (data) => {
      setGeneratedContent(data);
      toast({
        title: "Content Generated!",
        description: "Your AI-optimized article is ready.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate content. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.topic.trim()) {
      toast({
        title: "Topic Required",
        description: "Please enter a topic for your article.",
        variant: "destructive",
      });
      return;
    }

    generateContentMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof ContentFormData, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Auto-save functionality could be added here
  };

  const getGenerationStatus = () => {
    if (hasActiveKeys && (credits?.freeArticlesUsed || 0) < 10) {
      return {
        text: `⚡ Using your API key - ${10 - (credits?.freeArticlesUsed || 0)} free articles remaining`,
        canGenerate: true
      };
    } else if ((credits?.credits || 0) > 0) {
      return {
        text: `💳 Using credits - ${credits?.credits || 0} remaining`,
        canGenerate: true
      };
    } else {
      return {
        text: "💸 Payment required - Set up API keys for free articles or purchase credits",
        canGenerate: false
      };
    }
  };

  const status = getGenerationStatus();

  return (
    <section id="contentForm" className="py-16 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Generate Your AI-Optimized Content
          </h2>
          <p className="text-xl text-gray-600">
            Create content that ranks in Google's AI Overview using our advanced CRAFT Framework
          </p>
        </div>

        <Card className="shadow-xl border border-gray-200">
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Topic Input */}
              <div>
                <Label htmlFor="topic" className="text-sm font-medium text-gray-700 mb-2 block">
                  Topic (Required) <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="topic"
                  value={formData.topic}
                  onChange={(e) => handleInputChange('topic', e.target.value)}
                  placeholder="e.g., How to optimize for Google AI Overview"
                  className="w-full"
                  required
                />
              </div>

              {/* Keywords */}
              <div>
                <Label htmlFor="keywords" className="text-sm font-medium text-gray-700 mb-2 block">
                  Target Keywords
                </Label>
                <Input
                  id="keywords"
                  value={formData.keywords}
                  onChange={(e) => handleInputChange('keywords', e.target.value)}
                  placeholder="e.g., Google AI overview, AI overview optimization, CRAFT framework"
                  className="w-full"
                />
              </div>

              {/* Grid Layout for Select Fields */}
              <div className="grid md:grid-cols-2 gap-6">
                {/* Target Audience */}
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-2 block">
                    Target Audience
                  </Label>
                  <Select value={formData.audience} onValueChange={(value) => handleInputChange('audience', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select audience..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginners">Beginners</SelectItem>
                      <SelectItem value="professionals">Professionals</SelectItem>
                      <SelectItem value="experts">Experts</SelectItem>
                      <SelectItem value="general">General audience</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Niche */}
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-2 block">
                    Niche
                  </Label>
                  <Select value={formData.niche} onValueChange={(value) => handleInputChange('niche', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select niche..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="business">Business</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                      <SelectItem value="health">Health & Wellness</SelectItem>
                      <SelectItem value="finance">Finance</SelectItem>
                      <SelectItem value="education">Education</SelectItem>
                      <SelectItem value="lifestyle">Lifestyle</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                {/* Language */}
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-2 block">
                    Language
                  </Label>
                  <Select value={formData.language} onValueChange={(value) => handleInputChange('language', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="spanish">Spanish</SelectItem>
                      <SelectItem value="french">French</SelectItem>
                      <SelectItem value="german">German</SelectItem>
                      <SelectItem value="italian">Italian</SelectItem>
                      <SelectItem value="portuguese">Portuguese</SelectItem>
                      <SelectItem value="dutch">Dutch</SelectItem>
                      <SelectItem value="russian">Russian</SelectItem>
                      <SelectItem value="chinese">Chinese</SelectItem>
                      <SelectItem value="japanese">Japanese</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Word Count */}
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-2 block">
                    Word Count
                  </Label>
                  <Select value={formData.wordCount.toString()} onValueChange={(value) => handleInputChange('wordCount', parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="500">500 words</SelectItem>
                      <SelectItem value="1000">1000 words</SelectItem>
                      <SelectItem value="1500">1500 words</SelectItem>
                      <SelectItem value="2000">2000 words</SelectItem>
                      <SelectItem value="3000">3000 words</SelectItem>
                      <SelectItem value="5000">5000 words</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Generate Button */}
              <div className="text-center pt-6">
                <Button 
                  type="submit"
                  size="lg"
                  disabled={generateContentMutation.isPending || !status.canGenerate}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-12 py-4 text-lg font-semibold shadow-lg"
                >
                  {generateContentMutation.isPending 
                    ? "Generating with CRAFT Framework..." 
                    : "Generate Content with CRAFT Framework"
                  }
                </Button>
                <p className="text-sm text-gray-500 mt-3">
                  {status.text}
                </p>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Content Preview */}
        {generatedContent && (
          <ContentPreview content={generatedContent} />
        )}
      </div>
    </section>
  );
}
