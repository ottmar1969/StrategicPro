import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { aiService } from "./services/ai-service";
import { contentGenerator } from "./services/content-generator";
import { paymentService } from "./services/payment-service";
import { fraudDetection } from "./services/fraud-detection";
import { contentGenerationSchema, apiKeyConfigSchema } from "@shared/schema";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-05-28.basil",
});

export async function registerRoutes(app: Express): Promise<Server> {
  const DEFAULT_USER_ID = 1; // For demo purposes

  // Get user profile
  app.get("/api/user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Save API keys
  app.post("/api/api-keys", async (req, res) => {
    try {
      const { googleApiKey, openaiApiKey } = apiKeyConfigSchema.parse(req.body);
      const userId = DEFAULT_USER_ID;

      // Clear existing keys
      await storage.deleteApiKey(userId, 'google');
      await storage.deleteApiKey(userId, 'openai');

      const savedKeys = [];

      if (googleApiKey) {
        const encryptedKey = await aiService.encryptApiKey(googleApiKey);
        const key = await storage.saveApiKey({
          userId,
          provider: 'google',
          encryptedKey,
          isActive: true,
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
        });
        savedKeys.push(key);
      }

      if (openaiApiKey) {
        const encryptedKey = await aiService.encryptApiKey(openaiApiKey);
        const key = await storage.saveApiKey({
          userId,
          provider: 'openai',
          encryptedKey,
          isActive: true,
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
        });
        savedKeys.push(key);
      }

      // Update user to have API key
      await storage.setUserHasApiKey(userId, savedKeys.length > 0);

      res.json({ success: true, keysCount: savedKeys.length });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Test API connection
  app.post("/api/test-api", async (req, res) => {
    try {
      const { provider, apiKey } = req.body;
      const isValid = await aiService.testApiConnection(provider, apiKey);
      res.json({ valid: isValid });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Generate content
  app.post("/api/generate-content", async (req, res) => {
    try {
      const contentRequest = contentGenerationSchema.parse(req.body);
      const userId = DEFAULT_USER_ID;
      
      // Extract client information for fraud detection
      const clientIP = req.ip || req.connection.remoteAddress || '127.0.0.1';
      const userAgent = req.get('User-Agent') || '';
      const browserFingerprint = req.get('X-Browser-Fingerprint') || '';
      const sessionId = req.get('X-Session-ID') || '';

      // Perform fraud detection check
      const fraudCheck = await fraudDetection.checkDeviceFingerprint({
        userAgent,
        browserFingerprint,
        sessionId
      }, clientIP);

      if (!fraudCheck.allowed) {
        return res.status(403).json({ 
          message: `Access denied: ${fraudCheck.reason}`,
          riskScore: fraudCheck.riskScore
        });
      }

      if (fraudCheck.requiresVerification) {
        return res.status(429).json({ 
          message: `Suspicious activity detected: ${fraudCheck.reason}. Please verify your identity.`,
          riskScore: fraudCheck.riskScore
        });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check if user can generate content
      const canGenerate = await paymentService.canUserGenerateContent(userId);
      if (!canGenerate.allowed) {
        return res.status(402).json({ 
          message: "Insufficient credits or free articles",
          details: canGenerate 
        });
      }

      // Generate content using CRAFT framework
      const content = await contentGenerator.generateWithCRAFT(contentRequest, userId);
      
      // Save article
      const article = await storage.createArticle({
        userId,
        title: content.title,
        content: content.content,
        seoScore: content.seoScore,
        metadata: contentRequest,
        isPaid: canGenerate.method !== 'free',
        paymentMethod: canGenerate.method,
      });

      // Update user counters
      if (canGenerate.method === 'free') {
        await storage.updateUserFreeArticles(userId, (user.freeArticlesUsed || 0) + 1);
        // Track free article usage for fraud detection
        await fraudDetection.trackArticleGeneration(clientIP);
      } else if (canGenerate.method === 'credits') {
        await storage.updateUserCredits(userId, (user.credits || 0) - 1);
      }

      res.json({
        article,
        content,
        watermarked: !article.isPaid,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create payment intent for credits
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { amount, type, credits } = req.body; // amount in dollars
      const userId = DEFAULT_USER_ID;

      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          userId: userId.toString(),
          type,
          credits: credits?.toString() || "0",
        },
      });

      // Create payment record
      await storage.createPayment({
        userId,
        amount: Math.round(amount * 100),
        type,
        status: 'pending',
        stripePaymentIntentId: paymentIntent.id,
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Handle payment success webhook
  app.post("/api/payment-success", async (req, res) => {
    try {
      const { paymentIntentId } = req.body;
      
      // In production, verify webhook signature
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      
      if (paymentIntent.status === 'succeeded') {
        const userId = parseInt(paymentIntent.metadata.userId);
        const type = paymentIntent.metadata.type;
        const credits = parseInt(paymentIntent.metadata.credits || "0");

        if (type === 'credits' && credits > 0) {
          const user = await storage.getUser(userId);
          if (user) {
            await storage.updateUserCredits(userId, (user.credits || 0) + credits);
          }
        }

        // Update payment status - simplified for now
        // TODO: Implement getUserPayments method in storage if needed
      }

      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get article content (for download)
  app.get("/api/articles/:id", async (req, res) => {
    try {
      const articleId = parseInt(req.params.id);
      const article = await storage.getArticle(articleId);
      
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }

      res.json(article);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
