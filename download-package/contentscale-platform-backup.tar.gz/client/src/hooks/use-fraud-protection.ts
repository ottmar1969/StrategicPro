import { useState, useEffect } from 'react';

interface BrowserFingerprint {
  screen: string;
  timezone: string;
  language: string;
  platform: string;
  cookieEnabled: boolean;
  canvas: string;
  webgl: string;
  fonts: string;
  sessionId: string;
}

export function useFraudProtection() {
  const [fingerprint, setFingerprint] = useState<string>('');
  const [sessionId, setSessionId] = useState<string>('');

  useEffect(() => {
    generateFingerprint();
    generateSessionId();
  }, []);

  const generateFingerprint = async () => {
    const fp = await getBrowserFingerprint();
    const encoded = btoa(JSON.stringify(fp));
    setFingerprint(encoded);
  };

  const generateSessionId = () => {
    const stored = sessionStorage.getItem('fraud-session-id');
    if (stored) {
      setSessionId(stored);
    } else {
      const newId = generateRandomId();
      sessionStorage.setItem('fraud-session-id', newId);
      setSessionId(newId);
    }
  };

  const getBrowserFingerprint = async (): Promise<BrowserFingerprint> => {
    // Canvas fingerprinting
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.textBaseline = 'top';
      ctx.font = '14px Arial';
      ctx.fillText('Browser fingerprint 🔒', 2, 2);
    }

    return {
      screen: `${screen.width}x${screen.height}`,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      language: navigator.language,
      platform: navigator.platform,
      cookieEnabled: navigator.cookieEnabled,
      canvas: canvas.toDataURL(),
      webgl: getWebGLFingerprint(),
      fonts: getFontFingerprint(),
      sessionId: sessionId
    };
  };

  const getWebGLFingerprint = (): string => {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl') as WebGLRenderingContext | null;
      if (!gl) return '';
      
      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        const vendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
        const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
        return `${vendor}~${renderer}`;
      }
      return '';
    } catch {
      return '';
    }
  };

  const getFontFingerprint = (): string => {
    const fonts = [
      'Arial', 'Times', 'Courier', 'Helvetica', 'Georgia', 
      'Verdana', 'Times New Roman', 'Comic Sans MS', 'Impact',
      'Arial Black', 'Tahoma', 'Trebuchet MS', 'Palatino'
    ];
    
    return fonts.filter(font => isFontAvailable(font)).join(',');
  };

  const isFontAvailable = (font: string): boolean => {
    try {
      const testString = 'abcdefghijklmnopqrstuvwxyz0123456789';
      const testSize = '72px';
      const h = document.getElementsByTagName('body')[0];
      
      const s = document.createElement('span');
      s.style.fontSize = testSize;
      s.style.fontFamily = font;
      s.style.position = 'absolute';
      s.style.left = '-9999px';
      s.innerHTML = testString;
      h.appendChild(s);
      const fontWidth = s.offsetWidth;
      h.removeChild(s);
      
      return fontWidth > 0;
    } catch {
      return false;
    }
  };

  const generateRandomId = (): string => {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15) +
           Date.now().toString(36);
  };

  const getHeaders = () => {
    return {
      'X-Browser-Fingerprint': fingerprint,
      'X-Session-ID': sessionId,
    };
  };

  return {
    fingerprint,
    sessionId,
    getHeaders,
    isReady: fingerprint !== '' && sessionId !== ''
  };
}