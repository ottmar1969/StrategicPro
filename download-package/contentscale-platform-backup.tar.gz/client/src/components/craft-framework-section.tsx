import { X, Clipboard, Plus, CheckCircle, Heart } from "lucide-react";

export default function CRAFTFrameworkSection() {
  const craftSteps = [
    {
      icon: X,
      title: "Cut",
      description: "Remove fluff and focus on value. Every word serves a purpose.",
      color: "bg-red-100 text-red-600"
    },
    {
      icon: Clipboard,
      title: "Review", 
      description: "Optimize structure, headings, and SEO elements for maximum ranking power.",
      color: "bg-blue-100 text-blue-600"
    },
    {
      icon: Plus,
      title: "Add",
      description: "Enhance with visual elements, examples, and engaging multimedia suggestions.",
      color: "bg-green-100 text-green-600"
    },
    {
      icon: CheckCircle,
      title: "Fact-check",
      description: "Verify information accuracy and add credible sources for authority.",
      color: "bg-purple-100 text-purple-600"
    },
    {
      icon: Heart,
      title: "Trust", 
      description: "Build credibility with personal insights, stories, and authentic tone.",
      color: "bg-indigo-100 text-indigo-600"
    }
  ];

  const traditionalProblems = [
    "Generic, repetitive content",
    "Lacks human touch and authenticity", 
    "Poor SEO optimization",
    "Low user engagement"
  ];

  const craftBenefits = [
    "Unique, valuable content every time",
    "Human-like authenticity and voice",
    "Maximum SEO and AI Overview ranking", 
    "Higher conversion rates"
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            The CRAFT Framework: Your Secret Weapon
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our proprietary CRAFT Framework creates human-like content that ranks faster and converts better than generic AI content.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          {craftSteps.map((step, index) => (
            <div key={index} className="craft-card">
              <div className={`w-16 h-16 ${step.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                <step.icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
              <p className="text-gray-600 text-sm">{step.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Why CRAFT Framework Works for AI Overview</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-3">Traditional AI Content Problems:</h4>
              <ul className="space-y-2 text-gray-600">
                {traditionalProblems.map((problem, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <X className="w-5 h-5 text-red-500 mt-0.5" />
                    <span>{problem}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-3">CRAFT Framework Benefits:</h4>
              <ul className="space-y-2 text-gray-600">
                {craftBenefits.map((benefit, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
