// CRAFT Framework implementation utilities
export interface CRAFTAnalysis {
  cut: string;
  review: string;
  add: string;
  factCheck: string;
  trust: string;
}

export class CRAFTFramework {
  static generatePrompt(request: any): string {
    return `
You are ContentScale's advanced AI content generator. Create SEO-optimized content using the CRAFT Framework for Google AI Overview optimization.

CRAFT Framework Implementation:
- CUT: Remove unnecessary fluff, focus on value-driven content
- REVIEW: Optimize for SEO with proper headings, meta elements, and structure
- ADD: Suggest visual elements and engagement features
- FACT-CHECK: Ensure accuracy and include credible sources
- TRUST: Build authority with personal insights and authentic tone

Content Requirements:
- Topic: ${request.topic}
- Keywords: ${request.keywords || 'Auto-generate relevant keywords'}
- Target Audience: ${request.audience || 'General'}
- Niche: ${request.niche || 'General'}
- Language: ${request.language}
- Word Count: ${request.wordCount} words
- Google AI Overview Optimization: Structure content to appear in AI-generated search results

Focus on:
1. Question-focused structure for AI Overview inclusion
2. Concise, authoritative answers that Google AI can reference
3. E-E-A-T signals (Experience, Expertise, Authoritativeness, Trustworthiness)
4. Low-competition keyword targeting
5. Human-like authenticity that passes AI detection

Generate comprehensive, engaging content that dominates search results.
`;
  }

  static calculateSEOScore(content: string): number {
    let score = 50; // Base score
    
    // Check for headings
    if (content.includes('<h1>') || content.includes('<h2>')) score += 10;
    
    // Check for sufficient length
    if (content.length > 1000) score += 10;
    if (content.length > 2000) score += 5;
    
    // Check for lists
    if (content.includes('<ul>') || content.includes('<ol>')) score += 5;
    
    // Check for bold/emphasis
    if (content.includes('<strong>') || content.includes('<em>')) score += 5;
    
    // Check for internal structure
    if (content.split('\n').length > 10) score += 10;
    
    return Math.min(score, 95); // Cap at 95 for realism
  }

  static extractKeywords(content: string): string[] {
    // Simple keyword extraction - in production, use more sophisticated NLP
    const words = content.toLowerCase().match(/\b\w+\b/g) || [];
    const frequency: { [key: string]: number } = {};
    
    words.forEach(word => {
      if (word.length > 3) { // Filter short words
        frequency[word] = (frequency[word] || 0) + 1;
      }
    });

    return Object.entries(frequency)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 10)
      .map(([word]) => word);
  }
}
