import { useQuery } from "@tanstack/react-query";

export function useApiKeys() {
  const query = useQuery({
    queryKey: ["/api/user/1"],
    staleTime: 30000,
  });

  return {
    ...query,
    hasActiveKeys: query.data?.hasOwnApiKey || false,
  };
}
