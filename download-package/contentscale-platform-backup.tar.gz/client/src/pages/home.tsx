import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import GoogleAISection from "@/components/google-ai-section";
import CRAFTFrameworkSection from "@/components/craft-framework-section";
import ContentGenerationForm from "@/components/content-generation-form";
import PricingSection from "@/components/pricing-section";
import Footer from "@/components/footer";
import AISettingsModal from "@/components/ai-settings-modal";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <HeroSection />
      <GoogleAISection />
      <CRAFTFrameworkSection />
      <ContentGenerationForm />
      <PricingSection />
      <Footer />
      <AISettingsModal />
    </div>
  );
}
