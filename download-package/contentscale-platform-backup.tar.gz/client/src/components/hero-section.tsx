import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, CheckCircle, Globe, Users } from "lucide-react";

interface HeroSectionProps {
  onScrollToForm: () => void;
  onScrollToPricing: () => void;
}

export default function HeroSection({ onScrollToForm, onScrollToPricing }: HeroSectionProps) {
  const features = [
    { icon: Star, text: "Google AI Mode", color: "text-amber-300" },
    { icon: CheckCircle, text: "CRAFT Framework", color: "text-green-300" },
    { icon: Globe, text: "20+ Languages", color: "text-blue-300" },
    { icon: Users, text: "AI Overview Optimized", color: "text-purple-300" },
  ];

  return (
    <section className="relative hero-gradient text-white overflow-hidden">
      <div className="absolute inset-0 bg-black opacity-10"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
            Rank in Days Not Months
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-indigo-100 max-w-3xl mx-auto animate-slide-up">
            AI-powered content that dominates Google AI Overview using our exclusive CRAFT Framework and Google AI mode optimization
          </p>
          
          {/* Feature Badges */}
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {features.map((feature, index) => (
              <div key={index} className="feature-badge">
                <feature.icon className={`w-5 h-5 ${feature.color}`} />
                <span className="text-sm font-medium">{feature.text}</span>
              </div>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg"
              onClick={onScrollToForm}
              className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-4 text-lg font-semibold shadow-lg"
            >
              Get Your Free Article
            </Button>
            <Button 
              size="lg"
              variant="outline"
              onClick={onScrollToPricing}
              className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white border-white border-opacity-30 px-8 py-4 text-lg font-semibold"
            >
              View Pricing
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
