import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Zap } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PricingPackage {
  id: string;
  name: string;
  price: number;
  credits: number;
  pricePerCredit: number;
  popular: boolean;
  savings?: number;
}

export default function PricingSection({ onOpenAISettings }: { onOpenAISettings: () => void }) {
  const { toast } = useToast();

  const packages: PricingPackage[] = [
    {
      id: 'starter',
      name: 'Starter Pack',
      price: 25,
      credits: 5,
      pricePerCredit: 5.00,
      popular: false,
    },
    {
      id: 'popular', 
      name: 'Popular Pack',
      price: 40,
      credits: 10,
      pricePerCredit: 4.00,
      popular: true,
      savings: 20,
    },
    {
      id: 'professional',
      name: 'Professional Pack', 
      price: 75,
      credits: 25,
      pricePerCredit: 3.00,
      popular: false,
      savings: 40,
    },
  ];

  const features = [
    "High-quality articles",
    "All word counts (500-5000+ words)",
    "13+ languages supported", 
    "SEO optimization included",
    "CRAFT methodology applied",
    "Commercial intent analysis",
  ];

  const createPaymentMutation = useMutation({
    mutationFn: async (packageData: { amount: number; type: string; credits: number }) => {
      const response = await apiRequest("POST", "/api/create-payment-intent", packageData);
      return response.json();
    },
    onSuccess: (data) => {
      // Redirect to Stripe Checkout or handle payment
      toast({
        title: "Payment Processing",
        description: "Redirecting to payment...",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Payment Error",
        description: error.message || "Failed to process payment",
        variant: "destructive",
      });
    },
  });

  const handlePurchasePackage = (pkg: PricingPackage) => {
    createPaymentMutation.mutate({
      amount: pkg.price,
      type: 'credits',
      credits: pkg.credits,
    });
  };

  return (
    <section id="pricing" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose between credit packs for bulk generation or pay-per-article for flexibility. Use your own API key for 10 free articles!
          </p>
        </div>

        {/* API Key Advantage */}
        <Card className="bg-gradient-to-r from-green-500 to-emerald-600 text-white mb-12">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">🎉 Use Your Own API Key & Get 10 FREE Articles!</h3>
            <p className="text-lg mb-6">
              Connect your Google AI or OpenAI key and generate 10 articles completely free. Perfect for trying our CRAFT framework!
            </p>
            <Button 
              onClick={onOpenAISettings}
              className="bg-white text-green-600 hover:bg-gray-100 px-8 py-3 font-semibold"
            >
              <Zap className="w-4 h-4 mr-2" />
              Set Up API Key Now
            </Button>
          </CardContent>
        </Card>

        {/* Credit Packs */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {packages.map((pkg) => (
            <Card key={pkg.id} className={`pricing-card ${pkg.popular ? 'popular' : ''}`}>
              {pkg.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-indigo-500 text-white px-4 py-1">Most Popular</Badge>
                </div>
              )}
              
              <CardContent className="p-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{pkg.name}</h3>
                <div className="text-4xl font-bold text-gray-900 mb-2">${pkg.price}</div>
                <p className="text-indigo-600 font-medium mb-2">{pkg.credits} Credits</p>
                {pkg.savings && (
                  <p className="text-green-600 text-sm font-medium mb-4">Save {pkg.savings}%</p>
                )}
                <p className="text-sm text-gray-500 mb-6">${pkg.pricePerCredit.toFixed(2)} per credit</p>
                
                <ul className="space-y-3 mb-8 text-left">
                  <li className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="text-sm">{pkg.credits} high-quality articles</span>
                  </li>
                  {features.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                  {pkg.id === 'popular' && (
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      <span className="text-sm">Bulk generation support</span>
                    </li>
                  )}
                  {pkg.id === 'professional' && (
                    <>
                      <li className="flex items-center space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-sm">Bulk generation support</span>
                      </li>
                      <li className="flex items-center space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-sm">Priority processing</span>
                      </li>
                    </>
                  )}
                </ul>
                
                <Button 
                  onClick={() => handlePurchasePackage(pkg)}
                  disabled={createPaymentMutation.isPending}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 font-semibold"
                >
                  Buy {pkg.name}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Pay-per-article Option */}
        <Card className="shadow-lg border border-gray-200">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">No Credits? No Problem!</h3>
            <p className="text-gray-600 mb-6">When you run out of credits, choose flexible pay-per-article pricing:</p>
            
            <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto">
              <div className="bg-gray-50 rounded-lg p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Bulk Rate</h4>
                <div className="text-3xl font-bold text-indigo-600 mb-2">$1</div>
                <p className="text-sm text-gray-600">per article (bulk generation)</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-6">
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Single Article</h4>
                <div className="text-3xl font-bold text-indigo-600 mb-2">$10</div>
                <p className="text-sm text-gray-600">per individual article</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
