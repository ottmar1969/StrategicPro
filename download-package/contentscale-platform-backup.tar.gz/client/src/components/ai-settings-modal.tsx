import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Zap, Settings, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useApiKeys } from "@/hooks/use-api-keys";

interface AISettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AISettingsModal({ isOpen, onClose }: AISettingsModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { refetch: refetchApiKeys } = useApiKeys();

  const [apiKeys, setApiKeys] = useState({
    googleApiKey: "",
    openaiApiKey: "",
  });

  const [testResults, setTestResults] = useState({
    google: null as boolean | null,
    openai: null as boolean | null,
  });

  const saveApiKeysMutation = useMutation({
    mutationFn: async (keys: typeof apiKeys) => {
      const response = await apiRequest("POST", "/api/api-keys", keys);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "API Keys Saved",
        description: "Your API keys have been encrypted and saved securely.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/1"] });
      refetchApiKeys();
    },
    onError: (error: any) => {
      toast({
        title: "Save Failed",
        description: error.message || "Failed to save API keys",
        variant: "destructive",
      });
    },
  });

  const testApiMutation = useMutation({
    mutationFn: async ({ provider, apiKey }: { provider: string; apiKey: string }) => {
      const response = await apiRequest("POST", "/api/test-api", { provider, apiKey });
      return response.json();
    },
    onSuccess: (data, variables) => {
      setTestResults(prev => ({
        ...prev,
        [variables.provider]: data.valid
      }));
      toast({
        title: data.valid ? "Connection Successful" : "Connection Failed",
        description: data.valid 
          ? `${variables.provider} API key is working correctly.`
          : `${variables.provider} API key is invalid or not working.`,
        variant: data.valid ? "default" : "destructive",
      });
    },
    onError: (error: any, variables) => {
      setTestResults(prev => ({
        ...prev,
        [variables.provider]: false
      }));
      toast({
        title: "Test Failed",
        description: error.message || "Failed to test API connection",
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (field: string, value: string) => {
    setApiKeys(prev => ({ ...prev, [field]: value }));
    // Clear test result when key changes
    if (field === 'googleApiKey') {
      setTestResults(prev => ({ ...prev, google: null }));
    } else if (field === 'openaiApiKey') {
      setTestResults(prev => ({ ...prev, openai: null }));
    }
  };

  const handleTestConnection = (provider: string) => {
    const apiKey = provider === 'google' ? apiKeys.googleApiKey : apiKeys.openaiApiKey;
    if (!apiKey.trim()) {
      toast({
        title: "API Key Required",
        description: "Please enter an API key before testing.",
        variant: "destructive",
      });
      return;
    }
    testApiMutation.mutate({ provider, apiKey });
  };

  const handleSave = () => {
    if (!apiKeys.googleApiKey.trim() && !apiKeys.openaiApiKey.trim()) {
      toast({
        title: "No API Keys",
        description: "Please enter at least one API key.",
        variant: "destructive",
      });
      return;
    }
    saveApiKeysMutation.mutate(apiKeys);
  };

  const handleClear = () => {
    setApiKeys({ googleApiKey: "", openaiApiKey: "" });
    setTestResults({ google: null, openai: null });
    toast({
      title: "Cleared",
      description: "API key fields have been cleared.",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Settings className="w-5 h-5" />
            <span>AI Settings</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-2">Connect Your API Keys</h4>
            <p className="text-gray-600 text-sm">Add your own API keys to generate 10 FREE articles with our CRAFT framework!</p>
          </div>

          {/* Google AI Settings */}
          <Card className="border-indigo-200 bg-indigo-50">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-3">
                <Star className="w-5 h-5 text-indigo-600" />
                <h5 className="font-semibold text-indigo-900">Google AI (Recommended)</h5>
                <Badge className="bg-indigo-600 text-white text-xs">Primary</Badge>
              </div>
              <p className="text-sm text-indigo-700 mb-3">Best for AI Overview optimization and CRAFT framework implementation</p>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-sm font-medium text-indigo-900 mb-1 block">API Key</Label>
                  <Input
                    type="password"
                    value={apiKeys.googleApiKey}
                    onChange={(e) => handleInputChange('googleApiKey', e.target.value)}
                    placeholder="AIza..."
                    className="border-indigo-300 focus:ring-indigo-500"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <a 
                    href="https://makersuite.google.com/app/apikey" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-indigo-600 text-sm hover:underline flex items-center space-x-1"
                  >
                    <span>Get Google AI API Key</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                  <div className="flex items-center space-x-2">
                    {testResults.google === true && (
                      <Badge className="bg-green-100 text-green-800">✓ Valid</Badge>
                    )}
                    {testResults.google === false && (
                      <Badge className="bg-red-100 text-red-800">✗ Invalid</Badge>
                    )}
                    <Button 
                      size="sm"
                      onClick={() => handleTestConnection('google')}
                      disabled={testApiMutation.isPending}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white"
                    >
                      Test Connection
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* OpenAI Settings */}
          <Card className="border-gray-200 bg-gray-50">
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-3">
                <Zap className="w-5 h-5 text-gray-600" />
                <h5 className="font-semibold text-gray-900">OpenAI ChatGPT</h5>
                <Badge variant="secondary" className="text-xs">Fallback</Badge>
              </div>
              <p className="text-sm text-gray-600 mb-3">Backup provider for additional reliability</p>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-1 block">API Key</Label>
                  <Input
                    type="password"
                    value={apiKeys.openaiApiKey}
                    onChange={(e) => handleInputChange('openaiApiKey', e.target.value)}
                    placeholder="sk-..."
                    className="focus:ring-indigo-500"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <a 
                    href="https://platform.openai.com/api-keys" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-indigo-600 text-sm hover:underline flex items-center space-x-1"
                  >
                    <span>Get OpenAI API Key</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                  <div className="flex items-center space-x-2">
                    {testResults.openai === true && (
                      <Badge className="bg-green-100 text-green-800">✓ Valid</Badge>
                    )}
                    {testResults.openai === false && (
                      <Badge className="bg-red-100 text-red-800">✗ Invalid</Badge>
                    )}
                    <Button 
                      size="sm"
                      onClick={() => handleTestConnection('openai')}
                      disabled={testApiMutation.isPending}
                      variant="secondary"
                    >
                      Test Connection
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Settings Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
            <Button 
              variant="ghost"
              onClick={handleClear}
            >
              Clear All
            </Button>
            <Button 
              onClick={handleSave}
              disabled={saveApiKeysMutation.isPending}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-6"
            >
              {saveApiKeysMutation.isPending ? "Saving..." : "Save Settings"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
